

import Servicios.PersonaService;
import java.util.Date;



public class main {


    public static void main(String[] args) {
      
       PersonaService persona = new PersonaService(); 
     
        System.out.println("datos" + persona.crearPersona() );
         
        
       persona.calcularEdad(persona);


    }
    
}
